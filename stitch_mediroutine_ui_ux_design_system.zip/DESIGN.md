---
name: Serene Sanctuary & Chrono-Health
colors:
  surface: '#101320'
  surface-dim: '#101320'
  surface-bright: '#363847'
  surface-container-lowest: '#0a0d1a'
  surface-container-low: '#181b28'
  surface-container: '#1c1f2d'
  surface-container-high: '#262937'
  surface-container-highest: '#313443'
  on-surface: '#e0e1f4'
  on-surface-variant: '#c7c5d4'
  inverse-surface: '#e0e1f4'
  inverse-on-surface: '#2d303e'
  outline: '#918f9e'
  outline-variant: '#464552'
  surface-tint: '#c1c1ff'
  primary: '#c1c1ff'
  on-primary: '#1f1d89'
  primary-container: '#8b8df8'
  on-primary-container: '#1f1d89'
  inverse-primary: '#5152b9'
  secondary: '#5fdacb'
  on-secondary: '#003732'
  secondary-container: '#07a295'
  on-secondary-container: '#00302b'
  tertiary: '#e2b5ff'
  on-tertiary: '#451d61'
  tertiary-container: '#b386d1'
  on-tertiary-container: '#451c61'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1dfff'
  primary-fixed-dim: '#c1c1ff'
  on-primary-fixed: '#08006c'
  on-primary-fixed-variant: '#3838a0'
  secondary-fixed: '#7ef6e7'
  secondary-fixed-dim: '#5fdacb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#f3daff'
  tertiary-fixed-dim: '#e2b5ff'
  on-tertiary-fixed: '#2e014b'
  on-tertiary-fixed-variant: '#5d357a'
  background: '#101320'
  on-background: '#e0e1f4'
  surface-variant: '#313443'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 54px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 42px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 26px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  gutter-tablet: 1.5rem
  margin-tablet: 2rem
  gutter-desktop: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an empathetic, non-punitive health interface tailored for routine adherence, chronic care cadence, and conscious wellness. The aesthetic bridges high-end editorial calm with modern technical precision. Rather than inducing anxiety with harsh medical warnings, the interface functions as a restorative ambient chronometer—encouraging consistency through reassuring spatial balance, atmospheric visual depth, and dignified typographic authority.

The system synthesizes two dominant movements:
- **Refined Editorial Minimalism:** Broad negative space, disciplined margins, and commanding modern serif headlines evoke the quiet confidence of a timeless publication.
- **Atmospheric Soft-Tactile Modernism:** Deep slate and indigo substrates paired with soft translucent layer treatments, diffused tinted glows, and rounded pill-geometry convey physical reassurance and tactile calm without clinical sterility.

## Colors

The core palette balances a nocturnal indigo foundation with luminescent botanical and twilight accents:

- **Primary (`#8B8DF8`)**: Ethereal Iris. Serves as the primary brand locus, active chronological focal point, primary action states, and key interactive highlights.
- **Secondary (`#6EE7D8`)**: Bioluminescent Aqua. Used for positive affirmation, routine continuity, streak pulses, and active intake confirmations.
- **Tertiary (`#E0B0FF`)**: Twilight Heather. Applied to dosage differentiators, secondary metadata badges, and evening routine grouping.
- **Neutral (`#0D101D`)**: Midnight Slate. The deep base plane from which all surfaces emerge.

### Surface System
- **Base Canvas (`#090B14`)**: Root view canvas and behind-the-glass depth layer.
- **Surface Level 1 (`#121626`)**: Primary card backdrop and timeline stream track.
- **Surface Level 2 (`#1A2035`)**: Elevated interactive tiles, sheet modals, and input controls.
- **Surface Level 3 (`#252C48`)**: Chip containers, selected segmented tabs, and floating overlays.

### Non-Punitive Semantic Palette
- **Taken / Adhered (`#34D399` / Mint Sage)**: Affirmative, natural, stress-reducing positive state.
- **Skipped / Intentionally Paused (`#64748B` / Cool Slate)**: Non-judgmental neutral tone preserving agency and dignity.
- **Missed / Attention (`#FBBF24` / Warm Honey)**: Gentle, warm advisory notification replacing urgent or alarming emergency reds.

## Typography

The typographic system creates an intentional tension between classical humanism and contemporary clarity:

- **Editorial Serifs (`Newsreader`)**: Reserved for narrative milestones, daily time-block headings, medication titles, and reflective quotes. The gentle organic curves of `Newsreader` evoke personal care notebooks and thoughtful lifestyle volumes rather than an industrial medical charts.
- **Modern Sans-Serif (`Hanken Grotesk`)**: Provides razor-sharp legibility across technical dosage details, metric counters, medication schedules, and micro-labels.
- **Stylistic Rules**:
  - All uppercase labels in `label-sm` must apply expanded letter tracking (`letterSpacing: 0.08em`) to guarantee quick glances in low-light environments.
  - Numbers denoting dosage, pill count, and hour timestamps must employ tabular figures (`font-variant-numeric: tabular-nums`) to maintain vertical alignment within timeline streams.

## Layout & Spacing

The layout is built upon an 8pt baseline rhythm optimized for one-handed mobile ergonomic zones:

- **Mobile Viewport (0–599px)**: 4-column fluid layout with `1.25rem` (`20px`) margins. Interactive primary CTA controls and log gestures sit anchored in the bottom 40% vertical zone to optimize thumb reach.
- **Tablet / Foldable (600–1023px)**: 8-column layout with `2rem` (`32px`) margins. Medication timeline transitions to a dual-split view: scheduled streams pinned to the left, intake instructions and adherence history visible on the right.
- **Desktop / Companion Portal (1024px+)**: 12-column layout centered with a max-width container of `1180px`, allowing deep calendar insights and healthcare provider exports without visual stretching.

## Elevation & Depth

Visual hierarchy operates via tonal depth and subtle ambient optical blooms rather than harsh dropshadows:

- **Level 0 (Backdrop)**: Pure dark indigo `#090B14`.
- **Level 1 (Card & Module Foundation)**: `#121626` bounded by an inner border hairline (`1px solid rgba(255, 255, 255, 0.06)`).
- **Level 2 (Active Floating / Modal)**: `#1A2035` augmented with a dual ambient shadow:
  - `0 12px 32px -4px rgba(6, 8, 16, 0.65)`
  - `0 0 1px 1px rgba(255, 255, 255, 0.09)`
- **Luminescent Accent Halo**: Interactive routine components (such as an imminent medication window) project a soft, atmospheric color wash (`box-shadow: 0 8px 30px -6px rgba(139, 141, 248, 0.18)`), creating focus without inducing visual panic.

## Shapes

The geometric signature is inspired by capsules, pharmaceutical tablets, and organic drops:

- **Pill/Capsule Forms (`roundedness: 3`)**: Fully rounded geometry (`border-radius: 9999px` or minimum `2rem`) applied directly to status chips, primary action buttons, time-slot pickers, and dosage tags.
- **Card Containers**: Standardized to `1.5rem` (`24px`) corner radii, balancing soft tactile appeal with efficient content density.
- **Timeline Nodes**: Seamlessly rounded concentric rings that scale when interactive, reinforcing the routine's continuous visual pulse.

## Components

### 1. Buttons
- **Primary Action**: Pill-shaped (`border-radius: 9999px`), solid `#8B8DF8` fill with `#090B14` bold text (`label-lg`), paired with an ambient tinted glow. Active press triggers an internal scale compression (`transform: scale(0.97)`).
- **Secondary Action**: Translucent dark fill (`rgba(255, 255, 255, 0.08)`) with a hairline border (`rgba(255, 255, 255, 0.12)`) and iris-tinted typography.
- **Tertiary / Ghost**: Zero-fill container with underlined serif or muted sans labels for passive dismissals.

### 2. Status Chips & Badges
- **Taken**: Pill container with `rgba(52, 211, 153, 0.12)` fill, `1px solid rgba(52, 211, 153, 0.28)` border, and `#34D399` text. Prefixed by an organic filled dot.
- **Skipped**: Pill container with `rgba(100, 116, 139, 0.15)` fill, `1px solid rgba(100, 116, 139, 0.3)` border, and `#94A3B8` text.
- **Upcoming / Attention**: Pill container with `rgba(251, 191, 36, 0.12)` fill, `1px solid rgba(251, 191, 36, 0.28)` border, and `#FBBF24` text.

### 3. Chrono-Timeline Stream
- Continuous vertical spine: `2px` dashed or hairline solid stroke (`rgba(255, 255, 255, 0.08)`).
- **Time Nodes**: Double-ring concentric circle. Outer ring pulses softly when within the 30-minute adherence window.
- Completed events display an inset mint check icon; pending events hold an editorial numeral or dose icon.

### 4. Medication Cards
- Constructed on Surface Level 1 (`#121626`) with `1.5rem` radius and `1.25rem` inner padding.
- Visual hierarchy:
  - Top row: Scheduled time (`label-md`, iris-tinted) and semantic status chip.
  - Middle row: Medication name (`headline-md`, `Newsreader` font) paired with capsule icon tint.
  - Bottom row: Dosage specifications, food intake advisory badges (e.g., "With Meal"), and quick single-swipe or tap action trigger.

### 5. Inputs & Form Fields
- Surface Level 2 background with inset `1.25rem` horizontal padding.
- Border shifts from `rgba(255, 255, 255, 0.08)` to active `#8B8DF8` with a 2px blurred ambient glow on focus.
- Placeholder text uses muted slate (`#64748B`) set in `body-md`.

### 6. Interactive Pill Counters & Adherence Dials
- Circular or pill-shaped segmented controls with continuous haptic feedback.
- Progress visualization relies on continuous gradient sweeps transitioning softly between `#8B8DF8` and `#6EE7D8`, reinforcing daily balance rather than binary pass/fail grading.